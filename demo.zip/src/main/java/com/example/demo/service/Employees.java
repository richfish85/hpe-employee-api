package com.example.demo.service;

import com.example.demo.model.Employee;
import java.util.List;

public class Employees {

    private List<Employee> employeeList;

    public Employees() {
        employeeList = EmployeeManager.initializeEmployees();
    }

    public List<Employee> getAllEmployees() {
        return employeeList;
    }
}
