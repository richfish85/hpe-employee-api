package com.example.demo.controller;

import com.example.demo.model.Employee;
import com.example.demo.service.Employees;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
public class EmployeeController {

    private Employees employees = new Employees();

    @GetMapping("/employees")
    public Map<String, List<Employee>> getAllEmployees() {
        Map<String, List<Employee>> response = new HashMap<>();
        response.put("Employees", employees.getAllEmployees());
        return response;
    }
}
