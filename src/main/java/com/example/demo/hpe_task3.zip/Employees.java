package com.example.demo.service;

import com.example.demo.model.Employee;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class Employees {

    private final List<Employee> employeeList = new ArrayList<>(EmployeeManager.initializeEmployees());

    public List<Employee> getAllEmployees() {
        return employeeList;
    }

    public synchronized void addEmployee(Employee employee) {
        employeeList.add(employee);
    }
}
